<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta name="Description" content="Especialistas en sucesiones y herencias en la Argentina. Estudio Jurídico" />
<meta name="Keywords" content="sucesiones, susesion, susecion,susesiones, sucesión, sucesion, derecho, ley, leyes,  Justicia, Abogados, susesiones, Daniel Augelli Barth, Mazzantini Adriana, herencia, herencias, heredero,  herederos, testamento, testamentos, bienes gananciales, argentina, jurídico, judicial, juicio,  Estudio especializado en sucesiones y herencias en Argentina, estudio juridico" />
<meta name="" content="sucesiones, susesion, susecion,susesiones, sucesión, sucesion, derecho, ley, leyes,  Justicia, Abogados, susesiones, Daniel Augelli Barth, Mazzantini Adriana, herencia, herencias, heredero,  herederos, testamento, testamentos, bienes gananciales, argentina, jurídico, judicial, juicio,  Estudio especializado en sucesiones y herencias en Argentina, estudio juridico"  />

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index,follow" /> 
<meta name="googlebot" content="index,follow" /> 
<meta name="distribution" content="Global" /> 
<meta name="rating" content="Safe For Kids" /> 
<meta name="author" content="www.sucesion.org" /> 

<base href="http://sucesion.org/New/" target="_self" />

<title>Sucesión - Augelli Barth, Mazzantini &amp; Asoc.</title>


<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<script type="text/javascript">


  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-23810313-1']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 
</script>
<script type="text/javascript">
 
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-23809137-1']);
  _gaq.push(['_trackPageview']);
 
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
 
</script>

<link href="Estilos/Sucesion.css" rel="stylesheet" type="text/css" />
<script src="../Scripts/swfobject_modified.js" type="text/javascript"></script>
<style type="text/css">
a:link {
	color: #999966;
}
a:visited {
	color: #036;
}
a:hover {
	color: ;
}
a:active {
	color: ;
}
</style>
</head>

<body>
<?php
$para='consultas@sucesion.org';
$nombre=$_POST['nombre'];
$mail=$_POST['mail'];
$localidad=$_POST['localidad'];
$mensaje=$_POST['mensaje'];
$cuerpo="Mensaje:".$mensaje."\nNombre:".$nombre."\nLocalidad:".$localidad."\nMail:".$mail;

mail($para,"Mensaje - Sucesion.org",$cuerpo)
?>

<body class="CSS_Sucesion">
<table width="1126" height="670" align="center">
<tr>
  <th width="1120" height="663"><table width="1114" height="657" align="center" bgcolor="">
    <tr>
      <td width="1108" height="651"> 
      <table width="241"  height="527" border="0" align="left" bgcolor="">
        <tr>
          <td width="241" height="94" scope="row" background="" align="center" bgcolor="#999966"><object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="241" height="94">
            <param name="movie" value="media/Flash/Botones/Titulo_Sucesiones.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="6.0.65.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/Titulo_Sucesiones.swf" width="241" height="94">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="6.0.65.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID5" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Inicio.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Inicio.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID6" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Quienes_Somos.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Quienes_Somos.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID7" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Nuestro_Estudio.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Nuestro_Estudio.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID8" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Preguntas_Frecuentes.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Preguntas_Frecuentes.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID9" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Servicios_Utiles.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Servicios_Utiles.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
        <tr>
          <td height="25" scope="row" align="center"><object id="FlashID10" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
            <param name="movie" value="media/Flash/Botones/B_Contactenos.swf" />
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
            <!--[if !IE]>-->
            <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Contactenos.swf" width="163" height="23">
              <!--<![endif]-->
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="7.0.70.0" />
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
              <div>
                <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
              </div>
              <!--[if !IE]>-->
            </object>
            <!--<![endif]-->
          </object></td>
        </tr>
         <tr>
        <td height="25" scope="row" align="center"><object id="FlashID11" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="163" height="23">
          <param name="movie" value="media/Flash/Botones/B_Como_Llegar.swf" />
          <param name="quality" value="high" />
          <param name="wmode" value="transparent" />
          <param name="swfversion" value="7.0.70.0" />
          <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
          <param name="expressinstall" value="../Scripts/expressInstall.swf" />
          <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
          <!--[if !IE]>-->
          <object type="application/x-shockwave-flash" data="media/Flash/Botones/B_Como_Llegar.swf" width="163" height="23">
            <!--<![endif]-->
            <param name="quality" value="high" />
            <param name="wmode" value="transparent" />
            <param name="swfversion" value="7.0.70.0" />
            <param name="expressinstall" value="../Scripts/expressInstall.swf" />
            <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
            <div>
              <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
              <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
            </div>
            <!--[if !IE]>-->
          </object>
          <!--<![endif]-->
        </object></td>
      
        </tr>
        <tr>
        <td height="28" scope="row" align="center" >&nbsp;</td></tr>
        <tr>
          <td height="61" scope="row"  align="center" bgcolor="#E8E8D0" style="border:none"><p><em>Sitios de Interes Jurídico</em></p></td></tr>
          
   <tr>
        <td height="28" scope="row" align="center"><a href="http://www.cpacf.org.ar" target="new"><img src="images/logo_CPACF.jpg" width="120" height="28" style="border:none"/></a><a href="http://www.boletinoficial.gov.ar" target="new"><img src="images/boletin_oficial.gif" width="120" height="28" style="border:none"/></a></td></tr> 
   <tr>
        <td height="28" scope="row" align="center"><a href="http://www.csjn.gov.ar" target="new"><img src="images/logo_suprema_corte.jpg" width="120" height="28" style="border:none"/></a><a href="http://www.jus.gov.ar" target="new"><img src="images/logo_ministerio_justicia.jpg" width="120" height="28" style="border:none"/></a></td></tr> 
   <tr>
        <td height="28" scope="row" align="center"><a href="http://www.consejomagistratura.gov.ar" target="new"><img src="images/logo_poder_judicial.jpg" width="120" height="28" style="border:none"/></a><a href="http://www.pjn.gov.ar" target="new"><img src="images/logo_poder_judicial_ba.jpg" width="120" height="28" style="border:none"/></a></td></tr> 
   <tr>
        <td height="28" scope="row" align="center"><a href="http://www.cedom.gov.ar" target="new"><img src="images/Logo_Cedom.gif" width="120" height="28" style="border:none"/></a><a href="http://www.infoleg.gov.ar" target="new"><img src="images/logo_infoleg.jpg" width="120" height="28" style="border:none"/></a></td>
      </tr> 
         
       <tr>
        <td height="122" scope="row" align="center" bgcolor="#999966"></td>
      
        </tr>
      </table>
<table width="606" height="572" border="0" align="left">
  <tr>
            <td width="600" height="94" bgcolor="" style="text-align:center; font-size:36px; font-family:Mistral"><img src="images/Rotulo_Sucesion2.jpg" width="600" height="94" /></td>
          </tr>
          <tr>
            <td width="600" height="426"  bgcolor="#E8E8D0" align="center"><object id="FlashID2" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="603" height="424">
              <param name="movie" value="media/Flash/Banners/Info_Mensaje_Enviado_Suceciones.swf" />
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="6.0.65.0" />
              <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
              <!--[if !IE]>-->
              <object type="application/x-shockwave-flash" data="media/Flash/Banners/Info_Mensaje_Enviado_Suceciones.swf" width="603" height="424">
                <!--<![endif]-->
                <param name="quality" value="high" />
                <param name="wmode" value="transparent" />
                <param name="swfversion" value="6.0.65.0" />
                <param name="expressinstall" value="../Scripts/expressInstall.swf" />
                <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
                <div>
                  <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                  <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="112" height="33" /></a></p>
                </div>
                <!--[if !IE]>-->
              </object>
              <!--<![endif]-->
            </object></td>
          </tr>
          <tr>
            <td width="600" height="120" bgcolor="#999966" background=""><object id="FlashID4" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="600" height="120">
              <param name="movie" value="media/Flash/Banners/presentacion1.swf" />
              <param name="quality" value="high" />
              <param name="wmode" value="transparent" />
              <param name="swfversion" value="6.0.65.0" />
              <!-- Esta etiqueta param indica a los usuarios de Flash Player 6.0 r65 o posterior que descarguen la versión más reciente de Flash Player. Elimínela si no desea que los usuarios vean el mensaje. -->
              <param name="expressinstall" value="../Scripts/expressInstall.swf" />
              <!-- La siguiente etiqueta object es para navegadores distintos de IE. Ocúltela a IE mediante IECC. -->
              <!--[if !IE]>-->
              <object type="application/x-shockwave-flash" data="media/Flash/Banners/presentacion1.swf" width="600" height="120">
                <!--<![endif]-->
                <param name="quality" value="high" />
                <param name="wmode" value="transparent" />
                <param name="swfversion" value="6.0.65.0" />
                <param name="expressinstall" value="../Scripts/expressInstall.swf" />
                <!-- El navegador muestra el siguiente contenido alternativo para usuarios con Flash Player 6.0 o versiones anteriores. -->
                <div>
                  <h4>El contenido de esta página requiere una versión más reciente de Adobe Flash Player.</h4>
                  <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Obtener Adobe Flash Player" width="600" height="120" /></a></p>
                </div>
                <!--[if !IE]>-->
              </object>
              <!--<![endif]-->
            </object></td>
          </tr>
    </table>
        <table width="246" height="652" border="0" align="left">
          <tr>
            <td width="241" height="94" bgcolor="" background="images/fondo_contacto.png" align="center">&nbsp;</td>
          </tr>
          <tr>
            <td width="241" height="422" align="center" background="" bgcolor="#E8E8D0"><form style="height:424; width:241; color:#000000; font-family: 'Times New Roman', Times, serif; font-size:14px" action="enviar_mail.php" method="post" >
<p><em>(*) Nombre: </em><br />
<input name="nombre" type="text" size="20" maxlength="30"/></p>
<p><em>(*) Mail: </em><br />
<input name="mail" type="text" size="25" maxlength="30"/></p>
<p><em>(*) Localidad: </em><br />
<select name="localidad">
                <option selected="selected">Seleccionar...</option>
                <option value="exterior">Exterior del Pais</option>
                <option value="capfed">Capital Federal</option>
                <option value="baires">Buenos Aires</option>
                <option value="cordoba">C&oacute;rdoba</option>
                <option value="stafe">Santa Fe</option>
                <option value="mendoza">Mendoza</option>
                <option value="tucuman">Tucum&aacute;n</option>
                <option value="erios">Entre Rios</option>
                <option value="salta">Salta</option>
                <option value="misiones">Misiones</option>
                <option value="chaco">Chaco</option>
                <option value="corrientes">Corrientes</option>
                <option value="sgodelestero">Santiago del Estero</option>
                <option value="jujuy">Jujuy</option>
                <option value="sjuan">San Juan</option>
                <option value="rnegro">R&iacute;o Negro</option>
                <option value="formosa">Formosa</option>
                <option value="neuquen">Neuqu&eacute;n</option>
                <option value="chubut">Chubut</option>
                <option value="sanluis">San Luis</option>
                <option value="catamarca">Catamarca</option>
                <option value="larioja">La Rioja</option>
                <option value="lapampa">La Pampa</option>
                <option value="stacruz">Santa Cruz</option>
                <option value="tdelfuego">Tierra del Fuego</option>
              </select></p>
<p><em>(*) Mensaje: </em><br />
<textarea  name="mensaje" cols="25" rows="11" style="max-height:148px; max-width:200px; "></textarea></p>
<input name="submit" type="submit" value="Enviar" onclick=""/>
</form></td>
          </tr>
          <tr>
            <td height="28" bgcolor="" align="center"><img src="images/Contacto_telefonico_sucesion.jpg" width="241" height="28" style="border:none"/></td>
          </tr>
          <tr>
            <td height="28" bgcolor="" align="center"><a href="mailto:abmabogados@arnet.com.ar"><img src="images/Contacto_mail_sucesion.jpg" width="241" height="28" alt="Mail" style="border:none"/></a></td>
          </tr>
          <tr>
            <td height="28" bgcolor="" align="center"><a href="http://sucesion.org/New/como_llegar.html" target="_self"><img src="images/Contacto_direccion_sucesion.jpg" width="241" height="28" alt="Direccion" style="border:none"/></a></td>
          </tr>
          <tr>
            <td height="30" bgcolor="" align="center"><img src="images/Contacto_facebook_sucesion.jpg" width="241" height="28" alt="Facebook" style="border:none"/></td>
          </tr>
        
        </table>
      </td>
    </tr>
  </table></th>
</tr>
</table>
<script type="text/javascript">
swfobject.registerObject("FlashID4");
</script>
<script language="javascript">
function open_link()
{
parent.location="/New/index_nuevo.html"
}
swfobject.registerObject("FlashID");
swfobject.registerObject("FlashID2");
</script>
</body>
</html>